
import './App.css';
import Footer from './components/Footer';
import Header from './components/Header';
import fetchDataFromAPI from './services/fetchDataFromAPI';
import { BrowserRouter } from 'react-router-dom';


function App() {
  return (
    <>
      <BrowserRouter>
        <Header fetchData={fetchDataFromAPI}/>
        <h1>sdasda</h1>
        <h2>dsaduia</h2>
        <Footer/>
      </BrowserRouter>
  
    </>
  );
}

export default App;
