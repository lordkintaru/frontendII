import style from './Footer.module.css'



function Footer(){



    return(
     
        <footer >
            <div className={style.footerContent}>

            </div>
        </footer>
    )
}

export default Footer;